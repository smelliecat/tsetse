import numpy as np

class SquareLoss:
    """
    """

    def __init__(self, input_dimension, labels=None) -> None:
        self.input_layer = input_dimension
        self.labels = labels
    
    def set_labels(self,labels):
        self.labels = labels

    def forward(self):
        """Loss value is (1/2M) || X-Y ||^2"""
        self.in_array = self.input_layer.forward()
        self.num_data = self.in_array.shape[0]
        self.out_array = (0.5 / self.num_data) * np.linalg.norm(self.in_array - self.labels) ** 2
        return self.out_array

    def backward(self):
        """
        Gradient is (1/M) (X-Y), where N is the number of training samples
        """
        self.pass_back = (self.in_array - self.labels) / self.num_data
        self.input_layer.backward(self.pass_back)  # hand the gradient of loss with respect to inputs back to previous layer
        pass
    pass