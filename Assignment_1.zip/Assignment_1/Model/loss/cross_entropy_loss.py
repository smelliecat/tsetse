import numpy as np

class CrossEntropyLoss:
    """
    """

    def __init__(self, input_dimension, labels=None) -> None:
        pass
    
    def set_data(self, labels):
        pass

    def forward(self):
        pass

    def backward(self):
        """
        """
        pass